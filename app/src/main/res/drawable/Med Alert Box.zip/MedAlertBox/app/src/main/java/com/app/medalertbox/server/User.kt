package com.app.medalertbox.server

// User.kt
data class User(
    val id: Int,
    val name: String,
    val email: String
)
